import os
import argparse
import pandas as pd
import numpy as np
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LassoCV


def load_data(graph_index):
    path = os.path.join('data_train', f'data{graph_index}.csv')
    df = pd.read_csv(path)
    return df


def impute_and_scale(df):
    imputer = SimpleImputer(strategy='mean')
    X = imputer.fit_transform(df.values)
    scaler = StandardScaler()
    Xs = scaler.fit_transform(X)
    return pd.DataFrame(Xs, columns=df.columns)


def lasso_mb_for_variable(df, var_name, cv=5, random_state=0):
    if isinstance(var_name, int):
        var_name = df.columns[var_name]
    if var_name not in df.columns:
        raise ValueError(f"Variable {var_name} not found in dataframe columns")

    y = df[var_name].values
    X = df.drop(columns=[var_name])

    model = LassoCV(cv=cv, random_state=random_state, n_jobs=-1)
    model.fit(X, y)

    coefs = pd.Series(model.coef_, index=X.columns)
    # Keep non-zero coefficients as Markov blanket candidates
    scores = coefs.copy()
    return scores, model


def save_predictions(scores, effect_var, out_path):
    df = pd.DataFrame({
        'Cause': scores.index,
        'Effect': effect_var,
        'Score': scores.values
    })
    # sort by absolute score descending
    df['abs_score'] = df['Score'].abs()
    df = df.sort_values('abs_score', ascending=False).drop(columns=['abs_score'])
    df.to_csv(out_path, index=False)
    return df


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--graph', type=int, default=1, help='Index du graphe (1-5)')
    parser.add_argument('--var', default='V0', help='Variable cible (name or index)')
    parser.add_argument('--out', default=None, help='Fichier de sortie CSV')
    args = parser.parse_args()

    df = load_data(args.graph)
    df = impute_and_scale(df)

    # allow numeric index for var
    try:
        var_arg = int(args.var)
    except Exception:
        var_arg = args.var

    scores, model = lasso_mb_for_variable(df, var_arg)

    out_path = args.out or f'predictions_graph{args.graph}_{var_arg}.csv'
    result_df = save_predictions(scores, var_arg, out_path)

    selected = result_df[result_df['Score'] != 0]
    print(f"Saved predictions to {out_path}")
    print(f"Variables sélectionnées (non-nulles) pour {var_arg}:\n", selected)


if __name__ == '__main__':
    main()
