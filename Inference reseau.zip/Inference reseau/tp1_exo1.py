import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
import matplotlib.pyplot as plt
import networkx as nx
import os

# 1. Chargement des données
data_path = 'data_train/data1.csv'
target_path = 'data_train/target1.csv'
data = pd.read_csv(data_path)
target = pd.read_csv(target_path)

# 2. Affichage des aperçus
def print_overview():
    print('Aperçu des données:')
    print(data.head())
    print('\nAperçu des liens:')
    print(target.head())

# 3. Statistiques de base
d = data.shape[1]  # nombre de variables
n_points = data.shape[0]  # nombre de points d'observation
n_liens = target.shape[0]  # nombre de liens directs

def print_stats():
    print(f'Nombre de variables (d): {d}')
    print(f'Nombre de points d\'observation: {n_points}')
    print(f'Nombre de liens directs: {n_liens}')

# 4. Imputation aléatoire des valeurs manquantes
def impute_missing_random(df):
    for col in df.columns:
        mask = df[col].isna()
        if mask.any():
            values = df.loc[~mask, col]
            df.loc[mask, col] = np.random.choice(values, size=mask.sum(), replace=True)
    return df

data_imputed = impute_missing_random(data.copy())

# 5. Normalisation des données
scaler = StandardScaler()
data_normalized = pd.DataFrame(scaler.fit_transform(data_imputed), columns=data.columns)

# 6. Affichage des nuages de points pour chaque lien direct
def plot_links(data, target):
    for idx, row in target.iterrows():
        src, dst = row[0], row[1]
        plt.figure()
        plt.scatter(data[src], data[dst], alpha=0.5)
        plt.xlabel(src)
        plt.ylabel(dst)
        plt.title(f'Nuage de points: {src} → {dst}')
        plt.show()

# 7. Hypothèse sur le type de modèle générateur
def guess_model():
    print("D'après la structure des données et des liens, il est probable que le réseau ait été généré par un modèle linéaire ou un modèle de type graphe bayésien.")

# 8. Vérification de la présence de cycles dans le réseau
def has_cycles(target):
    G = nx.DiGraph()
    G.add_edges_from(target.values)
    try:
        cycles = list(nx.find_cycle(G, orientation='original'))
        if cycles:
            print('Le réseau contient des cycles.')
            return True
    except nx.exception.NetworkXNoCycle:
        print('Le réseau ne contient pas de cycles.')
        return False

# 9. Répéter pour les autres réseaux
def process_all_networks():
    for i in range(1, 6):
        print(f'\n--- Réseau {i} ---')
        data_i = pd.read_csv(f'data_train/data{i}.csv')
        target_i = pd.read_csv(f'data_train/target{i}.csv')
        d_i = data_i.shape[1]
        n_points_i = data_i.shape[0]
        n_liens_i = target_i.shape[0]
        print(f'Variables: {d_i}, Points: {n_points_i}, Liens: {n_liens_i}')
        data_i = impute_missing_random(data_i)
        data_i = pd.DataFrame(scaler.fit_transform(data_i), columns=data_i.columns)
        has_cycles(target_i)
        # plot_links(data_i, target_i)  # Décommentez pour afficher les nuages de points

if __name__ == '__main__':
    print_overview()
    print_stats()
    has_cycles(target)
    guess_model()
    # plot_links(data_normalized, target)  # Décommentez pour afficher les nuages de points
    process_all_networks()
