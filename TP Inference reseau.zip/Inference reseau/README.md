

# Inférence de réseaux

- `data_train/` : données d'entraînement pour les graphes 1 à 5 (`data1.csv` à `data5.csv`) et graphes vrais (`target1.csv` à `target5.csv`).
- `tp1.ipynb` : **notebook pour l'exercice 1  à 3**, incluant l'utilisation de la corrélation et des courbes PR sur les données de base.

- `TP3.ipynb` : **notebook pour le TP3**, avec :
  - Lasso pour la couverture de Markov de `V0` et pour toutes les variables.
  - Comparaison Lasso vs corrélation.
  - Graphical Lasso.
  - GENIE3 implémenté par RandomForest.
  - Gradient Boosting.
  - Calcul des courbes Précision/Recall et des scores Average Precision.

- `results_lasso/`, `results_glasso/`, `results_genie3/`, `results_gbm/` : dossiers de sortie contenant les prédictions enregistrées par méthode.


- `courbe_pr_rec_dir/` : dossiers et images de figures pour les courbes PR.

## Installation requise

Ce projet utilise Python et les bibliothèques suivantes :

- pandas
- numpy
- scikit-learn
- matplotlib
- scipy


## Lancement

Ouvrez les notebooks avec Jupyter Notebook ou JupyterLab :

```bash
jupyter notebook tp1.ipynb
jupyter notebook TP3.ipynb
```

Ou lancez directement JupyterLab :

```bash
jupyter lab
```

